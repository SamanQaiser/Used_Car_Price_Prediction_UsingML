# UOH_Final_Project
This repository will contain all the files required for the project for used car price predictor.
The link for the deployed website is: https://car-sancheet.herokuapp.com/
![image](https://user-images.githubusercontent.com/66842738/194742985-4316c71e-72e7-4223-8402-6f5c7119c14f.png)

